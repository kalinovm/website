<?php
if(isset($_POST['btn_submit'])){
	$op1 = $_POST['op1'];
	$op2 = $_POST['op2'];
	$operator = $_POST['operator'];
	
	switch($operator){
		case "+";
		echo "Rezultat je  " . ($op1+$op2);
		break;
		case "-";
		echo "Rezultat je " . ($op1-$op2);
		break;
		case "*";
		echo "Rezultat je " . ($op1*$op2);
		break;
		case "/";
		echo "Rezultat je " . ($op1/$op2);
		break;
	}
}
?>
<form method="post" action="">
<input type="text" name="op1" />
<select name ="operator">
	<option>+</option>
	<option>-</option>
	<option>*</option>
	<option>/</option>
</select>
<input type="text" name="op2" />
<input type="submit" name="btn_submit" value="=" />

</form>

